
from django.db import models
from datetime import datetime
from django.contrib.auth.models import User
from django.utils import timezone


class Movie(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    release_date = models.DateField()
    poster = models.ImageField(upload_to='movie_posters/')
    trailer = models.URLField(blank=True, null=True, max_length=200)
    casts = models.CharField(max_length=200, default='')
    rating = models.FloatField(null=True)
    language = models.CharField(max_length=50, default='')
    
    def __str__(self):
        return self.title
   
class Theater(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    movies = models.ManyToManyField(Movie, related_name='theaters')
    # capacity = models.PositiveIntegerField()
    # rows = models.PositiveIntegerField(default=0) 
    # columns = models.PositiveIntegerField(default=0) 

    def __str__(self):
        return self.name
    def get_available_seats(self, seat_type):
        return self.seattype_set.get(seat_type=seat_type).capacity - self.seat_set.filter(seat_type=seat_type, is_booked=True).count()

    
class SeatType(models.Model):
     
     theater = models.ForeignKey(Theater, on_delete=models.CASCADE, default=1)
     name = models.CharField(max_length=50, default='default_value')
     capacity = models.PositiveIntegerField(default=0)

     def __str__(self):
        return self.name

class SeatPrice(models.Model):
    theater = models.ForeignKey(Theater, on_delete=models.CASCADE, related_name='seat_prices')
    seat_type = models.ForeignKey(SeatType, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    capacity = models.PositiveIntegerField(default=0) 

    def __str__(self):
        return f"{self.theater.name} - {self.seat_type.name} - ${self.price}"    

class Showtime(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    theater = models.ForeignKey(Theater, on_delete=models.CASCADE)
    showtime = models.DateTimeField(default=datetime.now)
    TIME_SLOTS = [
        ('slot1', 'Show-1'),
        ('slot2', 'Show-2'),
        ('slot3', 'Show-3'),
        ('slot4', 'Show-4'),
    ]
    time_slot = models.CharField(max_length=10, choices=TIME_SLOTS, default='slot1')

    def __str__(self):
        return f"{self.movie.title} - {self.showtime.strftime('%Y-%m-%d %H:%M:%S')} - {self.time_slot}"


class Seat(models.Model):
    showtime = models.ForeignKey(Showtime, on_delete=models.CASCADE)
    seat_type = models.ForeignKey(SeatType, on_delete=models.CASCADE)
    is_booked = models.BooleanField(default=False)
    
class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    theater = models.ForeignKey(Theater, on_delete=models.CASCADE , null=True, default=None)
    theater_name = models.CharField(max_length=100, blank=True, null=True)
    showtime = models.ForeignKey(Showtime, on_delete=models.CASCADE)
    seat_type = models.ForeignKey(SeatType, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=0)
    booking_date = models.DateTimeField(default=timezone.now, blank=True)
    movie_name = models.CharField(max_length=255, blank=True)
    booked_date = models.DateField(null=True)

    def __str__(self):
        return f"Booking ID: {self.pk} - User: {self.user.username} - Theater: {self.theater.name if self.theater else 'No Theater Assigned'}"
    def save_booking_details(self, user, theater, showtime, seat_type, quantity):
        self.user = user
        self.theater = theater
        self.showtime = showtime
        self.seat_type = seat_type
        self.quantity = quantity
        self.save()

    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)