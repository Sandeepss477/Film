
from django.contrib import admin
from .models import Movie,Theater,Showtime,Seat,SeatPrice,SeatType,Booking
from .forms import TheaterForm
admin.site.register(Movie)
admin.site.register(Showtime)

class TheaterAdmin(admin.ModelAdmin):
    form = TheaterForm
    filter_horizontal = ('movies',)

admin.site.register(Theater,TheaterAdmin)
admin.site.register(Seat)
admin.site.register(SeatType)
admin.site.register(SeatPrice)


class SeatPriceAdmin(admin.ModelAdmin):
    list_display = ('seat_type_name', 'other_field', ...)  # Define the fields you want to display

    def seat_type_name(self, obj):
        return obj.seat_type.name  

class BookingAdmin(admin.ModelAdmin):
    list_display = ('user', 'theater', 'showtime', 'seat_type', 'quantity')

admin.site.register(Booking, BookingAdmin)   