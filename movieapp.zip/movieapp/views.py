from django.contrib.auth import login, authenticate,get_user_model
from django.shortcuts import render, redirect,get_object_or_404
from django.contrib import messages
from.models import Movie,Theater,Showtime,SeatPrice,Seat,SeatType,Booking
from .forms import BookingForm,SeatSelectionForm,UserRegistrationForm
from io import BytesIO
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from django.contrib.auth.decorators import login_required
from .forms import BookingConfirmationForm
from django.http import HttpResponseBadRequest
from django.contrib.auth.models import User





def home(request):
    return render(request, 'home.html')



def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
        
            return redirect('movieapp:login')  
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})



def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Login successful.")
            return redirect('movieapp:movies_list') 
        else:
            messages.error(request, "Invalid username or password. Please try again.")
    return render(request,'login.html')


def movies_list(request):
    movies = Movie.objects.all()
    context = {'movies': movies}
    return render(request, 'movies_list.html', {'movies': movies})



def movie_details(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    
    return render(request, 'movie_details.html', {'movie': movie})


def select_seats(request, theater_id):
    theater = get_object_or_404(Theater, pk=theater_id)
    showtimes = Showtime.objects.filter(theater=theater)
    
def book_now(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)
    theaters = None
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            selected_city = form.cleaned_data['city']
            # selected_date = form.cleaned_data['selected_date']
        
            theaters = Theater.objects.filter(
                showtime__movie=movie,
                location__icontains=selected_city
            ).distinct()

            context = {
                'movie': movie,
                'form': form,
                'theaters': theaters,
                # 'selected_date': selected_date,
            }
            return render(request, 'book_now.html', context)
    else:
        form =  BookingForm()

    context = {
        'form': form,
        'movie': movie,
        'theaters': theaters,
    }
    return render(request, 'book_now.html', context)


def select_seats(request, theater_id):
    theater = get_object_or_404(Theater, pk=theater_id)
    showtimes = Showtime.objects.filter(theater=theater)


    time_slot_choices = [
        (showtime.id, f"{showtime.time_slot} - {showtime.showtime.strftime('%H:%M')}")
        for showtime in showtimes
    ]
    
    seat_type_choices = SeatType.objects.filter(theater=theater)
    
    available_seats = {}
    seat_prices = {}
    for seat_type in seat_type_choices:

        seat_price = SeatPrice.objects.filter(theater=theater, seat_type=seat_type).first()
        if seat_price:
            booked_seats = Seat.objects.filter(
                showtime__theater=theater,
                seat_type=seat_type,
                is_booked=True
        ).count()
        available_seats[seat_type.name] = seat_type.capacity - booked_seats
        seat_prices[seat_type.name] = seat_price.price 
    total_amount = 0 
    movie = None 

    # 
    
    if showtimes.exists():
        showtime = showtimes.first()
        movie = showtime.movie
    context = {
        'theater': theater,
        'theater_name':theater.name,
        'time_slot_choices': time_slot_choices,
        'seat_type_choices': seat_type_choices,
        'available_seats': available_seats,
        'seat_prices': seat_prices,
        'total_amount': total_amount,
        'movie':movie,
    
     
    }
    
    return render(request, 'select_seats.html', context)


@login_required
def booking_success(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id)
    movie = booking.showtime.movie 
    selected_date = request.session.get('selected_date')

    selected_movie = request.session.get('selected_movie') 

    context = {
        'booking': booking,
        'movie': movie,
        'selected_date':selected_date,
        
    
    }

    return render(request, 'booking_success.html', context)

def process_booking(request):
    if request.method == 'POST':
        current_user = request.user
        selected_time_slot_id = request.POST.get('selected_time_slot')
        selected_seat_type_id = request.POST.get('selected_seat_type')
        quantity = request.POST.get('quantity')
        
        selected_seat_type = get_object_or_404(SeatType, id=selected_seat_type_id)
        
        
        selected_theater = selected_seat_type.theater 
        selected_time_slot = get_object_or_404(Showtime, pk=selected_time_slot_id)
    
        selected_movie_name = selected_time_slot.movie

        new_booking = Booking(
            user=current_user,
            theater=selected_theater,
            theater_name=selected_theater.name,  # Assign theater name
            showtime=selected_time_slot,
            seat_type=selected_seat_type,
            quantity=quantity,
            movie_name=selected_movie_name,
            # Additional fields related to the booking if needed
        )
        new_booking.save()
        return redirect('movieapp:booking_success', booking_id=new_booking.id)
        
    else:
        return render(request, 'error.html', {'error_message': 'Invalid request method'})
    


def booking_history(request):
        user_bookings = Booking.objects.filter(user=request.user)  # Fetch user's bookings
        return render(request, 'booking_history.html', {'user_bookings': user_bookings})


def delete_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    if request.method == 'POST':
        booking.delete()
        return redirect('movieapp:booking_history')