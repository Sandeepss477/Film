from django import forms
import datetime
from .models import Showtime,Theater,SeatType
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class UserRegistrationForm(UserCreationForm):
    phone_number = forms.CharField(max_length=15)  # You can adjust the max length as needed

    class Meta:
        model = User
        fields = ['username', 'phone_number', 'password1', 'password2']


    
class BookingForm(forms.Form):
    date = forms.DateField(widget=forms.SelectDateWidget(), initial=datetime.date.today)
    city = forms.CharField(max_length=100)
    
class TheaterForm(forms.ModelForm):
    class Meta:
        model = Theater
        fields = '__all__'

class SeatSelectionForm(forms.Form):
    time_slot = forms.ChoiceField(choices=[], label='Time Slot')
    children = forms.IntegerField(min_value=0, label='Number of Children')
    adults = forms.IntegerField(min_value=0, label='Number of Adults')
    seat_type = forms.ChoiceField(choices=[], label='Type of Seats')

    def __init__(self, *args, **kwargs):
        time_slot_choices = kwargs.pop('time_slot_choices')
        seat_type_choices = kwargs.pop('seat_type_choices')

        super(SeatSelectionForm, self).__init__(*args, **kwargs)

        self.fields['time_slot'].choices = time_slot_choices
        self.fields['seat_type'].choices = [(seat_type.id, seat_type.name) for seat_type in seat_type_choices]

class BookingConfirmationForm(forms.Form):
    showtime_id = forms.IntegerField()
    seat_type_id = forms.IntegerField()
    quantity = forms.IntegerField(min_value=0)
    

    def clean(self):
        cleaned_data = super().clean()
        return cleaned_data
