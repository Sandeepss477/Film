from django.urls import path
from . import views

app_name = 'movieapp'

urlpatterns = [
    path('', views.home, name='home'), 
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('movies/', views.movies_list, name='movies_list'),
    path('movie_details/<int:movie_id>/', views.movie_details, name='movie_details'),
    path('book_now/<int:movie_id>', views.book_now, name='book_now'),
    path('select_seats/<int:theater_id>/', views.select_seats, name='select_seats'),
    path('process_booking/',views.process_booking, name='process_booking'),
    path('booking_success/<int:booking_id>/', views.booking_success, name='booking_success'),
    path('booking-history/', views.booking_history, name='booking_history'),
    path('delete-booking/<int:booking_id>/', views.delete_booking, name='delete_booking'),
    ]

